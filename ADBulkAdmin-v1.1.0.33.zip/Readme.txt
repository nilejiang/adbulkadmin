http://www.usefulshare.com/adbulkadmin

https://sourceforge.net/projects/adbulkadmin/ 

ADBulkAdmin is a free tool for AD administrators to manage Active Directory users in bulk. You can use it to check a large number of users�� attributes, get users from OU, get members from Group, get all disabled users, get all locked out users, get users password expiration days, create a large number of AD users with specific attributes, unlock a large number of  users, reset a large number of  users�� passwords, enable or disable a large number of users, remove a large number of users, set a large number of users�� properties, check a large number of  groups, add a large number of  users to group or remove a large number of users from group, test users if using easy password, get user lock status on all the domain controllers.

Prerequisite:

1. .net Framework 4.0 or higher.
2. Office 2007 or higher. Run ADBulkAdmin.exe in 32 or 64 bit Office folder according to your office version. With Office Excel, you can create a large number of users or set properties for users. If you are using Office 2016 and you can��t operate Excel, please download and install Microsoft Access Database Engine 2010 Redistributable from http://www.microsoft.com/en-US/download/details.aspx?id=13255  or Microsoft Access 2013 Runtime https://www.microsoft.com/en-us/download/details.aspx?id=39358
3. Files of the tool: ADBulkAdmin.exe, ADBulkAdmin.exe.config, users.xlsx, ADBATData.accdb. (You must not change the name of these files!)
4. User with necessary AD permissions, and run this tool as administrator.

Update History:

2013.1.23 v1.0.0.1

Add Lync and DN attribute in Check User feature to check if the user is enabled Lync and get the user��s OU path via DN.

2013.3.11 v1.0.0.2

Add account expires time attribute etc. and fix some small bugs.

2013.3.11 v1.0.0.3

Add telephoneNumber, mobile and description etc. to create new users and fix some small bugs.

2013.3.11 v1.0.0.4

Add password and mail attributes to create new users and set users.

2014.2.8 V1.0.0.5

Add new feature of specifying domain controller.

2014.2.16 V1.1.0.0

Enhance dc specify feature. Generate two versions for bothe 32bit office and 64bit office, fix some small bugs and exceptions.

2014.5.15 V1.1.0.1

Fix the bug of wrong result when adding to group or removing from group, add some new user attributes.

2014.8.26 V1.1.0.2

Select ��User must change password at next logon�� when creating new users and reseting user pasword.

2014.9.17 V1.1.0.3

Add the feature of recording and searching logs to Access database.

2014.11.4 V1.1.0.4

Add the feature that user can select attributes when checking users, creating new users and setting users, fix some small bugs.

2015.4.29 V1.1.0.5

Add Unlock User function and fix some small bugs, like reset name attribute when change Display Name, create user successfully when name includes ��,�� etc..

2015.5.1 V1.1.0.6

Add all the common AD user attributes to the tool when checking, creating and modifying users, can specify ou path when creating new users, fix some small bugs.

2015.8.12 V1.1.0.7

Add attributes employeeNumber and proxyAddresses for check users, create new users and set properties according to user��s requirement.

2015.8.17 V1.1.0.8

Add Check Update featue in About. It can check if there is a new version and can download the latest version.

2015.9.30 V1.1.0.9

Add some new attributes like ProfilePath, HomeDrive and HomeDirectory and so on. Add detail logs when operating. Fix some small bugs and make some optimizations like use samAccountName as cn when not input the DisplayName attribute.

2015.12.03 V1.1.0.10

Fix the bug that can��t open at the second time if your computer doesn��t join domain and you have specified a domain controller and save the settings. It works OK now.

2016.1.21 V1.1.0.11

Fix some small bugs, add Export to CSV feature, add Get Users Feature that get users from OU, get members from Group, get all disabled users, get all locked out users, get password expiration days users. Add Test Password feature, add search user Lockout and Lastlogon status on all domain controllers. Test Password and Lockout&LastLogon feature are locked by default, if you need it please send email to me, maybe you need to pay a little to unlock it.

2016.1.21 V1.1.0.12

Fixed Test Password bug, add whencreated and LogOnTo(userworkstations) attributes, add PasswordExpireDays to Lockou&LastLogon feature. Test Password and Lockout&LastLogon feature are locked by default, if you need it please send email to me, maybe you need to pay a little to unlock it.

2016.4.30 V1.1.0.13

Fixed the bug of profiepath when including %username% in the value. Add Logon Script attribute and Password Never Expires to NewUser and Set Properties feature. Add Password Never Expires to Reset Password feature.

2016.7.16 V1.1.0.14

Fixed a small bug that can not select all via Ctrl + A on Add to Group etc. Unlock Lockout&LastLogon for free.

2016.7.23 V1.1.0.15

Fixed the bug when create New User or Set Properties to the OU path which contains special character like ��/��,  also for Check User feature.

2016.12.10 V1.1.0.16

Fixed a small bug, changed the Settings desgin, can add or remove the attributes to the list and sort the attributes, so that can check, create or set user attributes more easily.

2017.10.29-v1.1.0.18
Optimize the source code, add UPN to Set Properties, change ProxyAddresses to split with ��;��, add value without overwriting existed values.

2017.12.16 V1.1.0.19

Change About to check update automatically aftering opening and show if it is the latest version. 
Can add new user to multiple existed groups split with semicolon ; when creating new users.
Can add multiple users to multiple groups split with semicolon ; with Add to Group feature.
Can remove multiple users from multiple groups split with semicolon ; with Remove from Group feature.
Add Report feature that can generate operation report for all users or one user.

2018.1.14 V1.1.0.20

Change ProxyAddresses to split with "^" for Check User, New User and Set Properties features according user's requirements, add switch for appending or replacing ProxyAddresses values in Settings->SetUserAttrList.

2018.5.6 V1.1.0.21

Fixed a bug that can't delete user contains child object.
Added samAccoutName length check when creating new users.

2018.6.18 V1.1.0.22

Added a new feature that can get group list users belong to and export to CSV.

2018.8.19 V1.1.0.23

Added new attribute otherTelephone and optimize the code.

2018.11.25 V1.1.0.24

Added new attributes division and info, fixed a small bug when saving logs containing "'" in attributes.

2019.2.8 V1.1.0.25

Added get groups, contacts and computers from OU, get inactive days computers.

2019.3.3 V1.1.0.26

Added extersionAttribute14, added Scripts samples, please contact Nile to get.

2019.5.12 V1.1.0.28

Added attribute name(cn), changed UPN input type to full value like abc@abc.com , added new feature User Last Logon Report.

2019.5.19 V1.1.0.29

Added display user disabled status in User Last Logon Report, added determine if has existed UPN when creating new users.

2019.6.2 V1.1.0.30

Added middle name according user's request.

2019.6.29 V1.1.0.31

Fixed the bug that get error when creating new user if selected UPN but not set value.

2019.7.06 V1.1.0.32

Fixed some small bugs if contains specail characters in user or OU name, doesn't load all groups by default.

2019.7.28 V1.1.0.33

Adjusted a label layout, fixed a small bug.